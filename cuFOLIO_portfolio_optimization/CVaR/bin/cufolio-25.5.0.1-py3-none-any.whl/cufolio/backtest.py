'''
SPDX-FileCopyrightText: Copyright (c) 2021-2025 NVIDIA CORPORATION &
AFFILIATES. All rights reserved. SPDX-License-Identifier:
LicenseRef-NvidiaProprietary

NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
property and proprietary rights in and to this material, related
documentation and any modifications thereto. Any use, reproduction,
disclosure or distribution of this material and related documentation
without an express license agreement from NVIDIA CORPORATION or
its affiliates is strictly prohibited.
'''

import numpy as np
import pandas as pd
from sklearn.neighbors import KernelDensity

import matplotlib.pyplot as plt
import seaborn as sns

from . import cvar_utils, utils
from .portfolio import Portfolio

class portfolio_backtester:
    def __init__(self, test_portfolio, returns_dict, risk_free_rate = 0.0, test_method ='historical', benchmark_portfolios = None):
        '''
        Params: 
        :test_portfolio: Portfolio class - portfolio to test
        :returns_dict: dict - {'return_type': str, 'returns': numpy array, 'dates': list,
                               'mean': numpy array, 'covariance': numpy ndarray, 'tickers': list}
        :test_method: str - historical or simulated scenarios
        :risk_free: float - risk free rate
        :benchmark_portfolios: user-input or existing custom portfolios, if None, then set to equal-weight portfolio.
        '''
        
        self.test_portfolio = test_portfolio
        self.test_method = test_method.lower()
        self.benchmark_portfolios = self._generate_benchmark_portfolios(benchmark_portfolios)

        self._dates = returns_dict['dates']
        self._return_type = returns_dict['return_type']
        self._return_mean = returns_dict['mean']
        self._covariance = returns_dict['covariance']
        self._returns = returns_dict['returns']
        
        self._R = self._get_return_scenarios()
        
        if self._return_type == 'LOG':
            self.risk_free_rate = np.log(1+risk_free_rate)
        elif self._return_type == 'LINEAR':
            self.risk_free_rate = risk_free_rate 
        
        self._backtest_column_names = ['returns', 'cumulative returns', 'portfolio name', 'mean portfolio return', 'sharpe', 'sortino', 'max drawdown']
        
    def _generate_benchmark_portfolios(self, benchmark_portfolios):
        if benchmark_portfolios is None: #when benchmark_portfolios is not provided, default to equal-weight portfolio
            return self._generate_equal_weights_portfolio(self.test_portfolio.tickers, self.test_portfolio.cash)
        elif isinstance(benchmark_portfolios, pd.DataFrame): #if custom, then set to input portfolios stored in optimization problem
            return benchmark_portfolios['portfolio'].to_list()
        elif isinstance(benchmark_portfolios, list): 
            return benchmark_portfolios
        else:
            raise ValueError('Unacceptable input format.\n Please provide the portfolios in compliant format (DataFrame)')
        
    def _generate_equal_weights_portfolio(self, tickers, cash):
        n_assets = len(tickers)
        weights = (np.ones(n_assets)- cash) / n_assets
        eq_weight_portfolio = Portfolio(name = 'equal-weight', tickers= tickers, weights= weights, cash=cash)
        return [eq_weight_portfolio]
        
    def _generate_simulated_scenarios(self, generation_method = 'kde', num_scen = 5000):
        '''
        Params: 
        :generation_method: str - how to generate scenarios (Gaussian, KDE, etc.)
        :num_scen: int - number of scenarios to generate
        
        Return: 
        :R: numpy ndarray (num_scen, n_assets)
        '''
        generation_method = str(generation_method).lower()
        if generation_method == 'gaussian': #fit Gaussian
            R = np.random.multivariate_normal(self._return_mean, self._covariance, size = num_scen)
            
        elif generation_method == 'kde': #kde distribution
            R = self._generate_samples_kde(self._returns, num_scen, bandwidth=0.005)
            
        else: 
            raise NotImplementedError("Invalid Generation Method!")
        return R
    
    def _generate_samples_kde(self, returns_data, num_scen, bandwidth, kernel='gaussian'):
        '''
        fit KernelDensity to data and return new samples of size num_scen
        
        params:
        :returns_data: numpy ndarray
        :bandwidth: bandwidth of the Kernel Density estimator
        '''
        kde = KernelDensity(kernel=kernel, bandwidth=bandwidth).fit(returns_data)
        new_samples = kde.sample(num_scen)

        return new_samples
    
    def _get_return_scenarios(self):
        '''
        generate returns based on test method
        '''
        if self.test_method == 'historical': 
            R = self._returns

        elif self.test_method == 'kde_simulation':
            R = self._generate_simulated_scenarios(generation_method = 'kde')

        elif self.test_method == 'gaussian_simulation':
            R = self._generate_simulated_scenarios(generation_method = 'gaussian')

        else: 
            raise NotImplementedError('invalid test method!')
            
        return R
    
    def backtest_against_benchmarks(self, plot_returns = False, ax = None, cut_off_date = None, title = None):
        '''
        plot the cumulative returns of the given portfolio and the benchmark portfolio(s)
        '''
        
        backtest_results = pd.DataFrame({}, columns = self._backtest_column_names)
        
        #backtest optimal portfolio
        backtest_results = pd.concat([backtest_results, self.backtest_single_portfolio(self.test_portfolio)])
        
        for portfolio in self.benchmark_portfolios:
            result = self.backtest_single_portfolio(portfolio)
            backtest_results = pd.concat([backtest_results, result], ignore_index = True)
        
        backtest_results.set_index('portfolio name', inplace = True)
        if plot_returns: 
            plt.rcParams.update({'font.size': 8})
            sns.set(rc={"figure.dpi":100, 'savefig.dpi':300})
            sns.set_palette(palette="tab10")
            sns.set_style('white')
            
            if ax is None:
                fig, ax = plt.subplots(figsize=(10, 7))
            cumulative_returns_dataframe = pd.DataFrame([], index = pd.to_datetime(self._dates), columns = backtest_results.index)
            
            for ptf_name, row in backtest_results.iterrows():
                cumulative_returns = row['cumulative returns']
                cumulative_returns_dataframe[ptf_name] = cumulative_returns 
            
            sns.lineplot(data = cumulative_returns_dataframe, legend = 'auto')
            plt.xlabel('Date', fontsize = 8)
            plt.ylabel(f'Cumulative {self._return_type.lower()} returns', fontsize = 8)
            plt.xticks(rotation=50, fontsize = 8)
            plt.yticks(fontsize = 8)
            plt.title(title, fontsize = 10)
            
            if cut_off_date is not None: 
                cut_off_date = pd.to_datetime(cut_off_date)
                ax.axvline(x = cut_off_date, color = 'grey', linestyle = '--')
            

        return backtest_results, ax
        
    def backtest_single_portfolio(self, portfolio):
        '''
        run the backtest for given portfolio with weights and cash
        ''' 
        if self._return_type == 'LOG' or self._return_type == 'LINEAR':
        #compute Sharpe Ratio, Sortino Ratio, and Max Drawdown (MDD)
            portfolio_returns = self._compute_portfolio_returns_with_cash(portfolio.weights, portfolio.cash)
            backtest_result = self._compute_return_metrics(portfolio.name, portfolio_returns, portfolio.cash)
        else:
            raise NotImplementedError('Return type not supported yet!')

        return backtest_result
    
    def _compute_return_metrics(self, portfolio_name, returns, cash):
        '''
        calculate sharpe, sortino, max drawdown
        '''
        mean_return = np.mean(returns) + cash * self.risk_free_rate
        excess_returns = returns - self.risk_free_rate
        if self._return_type == 'LINEAR':
            cumulative_returns = np.cumsum(returns)
        elif self._return_type == 'LOG':
            cumulative_returns = np.exp(np.cumsum(returns))
            
        sharpe = self.sharpe_ratio(excess_returns)
        sortino = self.sortino_ratio(excess_returns)
        mdd = self.max_drawdown(cumulative_returns)
        
        result = pd.Series([returns.to_numpy(), cumulative_returns.to_numpy(), portfolio_name, mean_return, sharpe, sortino, mdd], index = self._backtest_column_names)
        
        return result.to_frame().T

    def _compute_portfolio_returns_with_cash(self, weights, cash):
        return self._R @ weights + self.risk_free_rate * cash
    
    def sharpe_ratio(self, excess_returns):
        mean_excess_return = np.mean(excess_returns)
        std_dev_excess_return = np.std(excess_returns)
        sharpe_ratio = mean_excess_return / std_dev_excess_return * np.sqrt(252)
        
        return sharpe_ratio
    
    def sortino_ratio(self, excess_returns):
        mean_excess_return = np.mean(excess_returns)
        downside_returns = excess_returns[excess_returns < 0]
        downside_deviation = np.std(downside_returns)
        
        sortino_ratio = mean_excess_return / downside_deviation * np.sqrt(252)
        
        return sortino_ratio
    
    def max_drawdown(self, cumulative_returns): 
        # Convert log returns to cumulative portfolio values
        
        # Initial portfolio value (assuming it starts at 1 for simplicity)
        initial_portfolio_value = 1
        portfolio_values = initial_portfolio_value * cumulative_returns

        # Compute the running maximum
        running_max = np.maximum.accumulate(portfolio_values)

        # Compute the max drawdown
        drawdown = (running_max - portfolio_values) / running_max
        max_drawdown = np.max(drawdown)
        
        return max_drawdown

    
