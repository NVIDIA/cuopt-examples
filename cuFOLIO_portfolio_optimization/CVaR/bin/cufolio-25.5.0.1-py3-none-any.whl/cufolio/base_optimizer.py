'''
SPDX-FileCopyrightText: Copyright (c) 2021-2025 NVIDIA CORPORATION &
AFFILIATES. All rights reserved. SPDX-License-Identifier:
LicenseRef-NvidiaProprietary

NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
property and proprietary rights in and to this material, related
documentation and any modifications thereto. Any use, reproduction,
disclosure or distribution of this material and related documentation
without an express license agreement from NVIDIA CORPORATION or
its affiliates is strictly prohibited.
'''

from dataclasses import dataclass
import datetime as dt
import os
import json

import numpy as np
import pandas as pd
import math
import scipy
from scipy.stats import norm
from scipy.sparse import csr_matrix
from sklearn.neighbors import KernelDensity
import cvxpy as cp

import matplotlib.pyplot as plt
import seaborn as sns


class BaseOptimizer:
    """
    Instance variables:
    - ``input_file_name`` - str
    - ``input_data`` - DataFrame
    - ``return_type`` - str
    - ``n_assets`` - int
    - ``tickers`` - str list
    - ``weights`` - numpy ndarray (n_assets, ) 
    - ``weights_previous`` - numpy ndarray: weights of the existing portfolio
    - ``cash`` - float
    - ``risk_measure`` - str: e.g. CVaR or variance

    Public methods:

    - ``set_weights()`` creates self.weights (np.ndarray) from a weights dict
    - ``clean_weights()`` rounds the weights and clips near-zeros.
    - ``calculate_returns()`` return the mean, covariance of the log returns (assuming normally distributed).
    """

    def __init__(self, returns_dict, weights_previous, risk_measure):
        self.returns_dict = returns_dict
        self.tickers = returns_dict['tickers']
        self.n_assets = len(self.tickers)
        self.risk_measure = risk_measure
        
        if not weights_previous:  #(n_assets,) array of existing portfolio weights; create uniform distributed weights if weights_previous not exist
            self.weights_previous = np.ones(self.n_assets) / self.n_assets
        else: 
            self.weights_previous = weights_previous



    


