'''
SPDX-FileCopyrightText: Copyright (c) 2021-2025 NVIDIA CORPORATION &
AFFILIATES. All rights reserved. SPDX-License-Identifier:
LicenseRef-NvidiaProprietary

NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
property and proprietary rights in and to this material, related
documentation and any modifications thereto. Any use, reproduction,
disclosure or distribution of this material and related documentation
without an express license agreement from NVIDIA CORPORATION or
its affiliates is strictly prohibited.
'''

from dataclasses import dataclass
import datetime as dt
import os
import json

import numpy as np
import pandas as pd
import math
import scipy
from scipy.stats import norm
from scipy.sparse import csr_matrix
import sklearn.neighbors
import cuml.neighbors
import cvxpy as cp

import matplotlib.pyplot as plt
import seaborn as sns

from . import utils, base_optimizer, cvar_optimizer, scenario_generation
from .portfolio import Portfolio

FILE_FORMAT = '.json'

def calculate_returns(file_name, regime_dict, return_type, cvar_params, device = 'CPU'):
    '''
    Create data for CVaR optimizer
    
    Params:
    ``file_name``: str
    ``regime_dict``: dict
    ``return_type``: str
    ``cvar_params``: CVaR_Parameters
    
    '''
    returns_dict = utils.calculate_returns(file_name, regime_dict, return_type)
    cvar_returns_dict = generate_CVaR_data(returns_dict, cvar_params, device = 'CPU')
    
    return cvar_returns_dict

def generate_samples_kde(num_scen, returns_data, bandwidth, kernel='gaussian', device = 'CPU'):
    '''
    fit KernelDensity to data and return new samples of size num_scen

    params:
    :returns_data: numpy ndarray
    :bandwidth: bandwidth of the Kernel Density estimator
    '''
    if device == 'CPU':
        
        kde = sklearn.neighbors.KernelDensity(kernel=kernel, bandwidth=bandwidth).fit(returns_data)
        
    elif device == 'GPU':
        
        kde = cuml.neighbors.KernelDensity(kernel=kernel, bandwidth=sbandwidth).fit(returns_data)
    
    else: 
        raise ValueError('Invalid Device: CPU or GPU!')
    new_samples = kde.sample(num_scen)

    return new_samples

def generate_CVaR_data(returns_dict, cvar_params, device = 'CPU'):
    '''
    This function generates the CVaR_data dataclass that is used in CVaR optimization

    Params: 
    ''returns_dict'': Gaussian, kde, or historical

    Return: 
    data: CVaR_Data dataclass
    '''
    return_mean = returns_dict['mean']
    covariance = returns_dict['covariance']
    returns_data = returns_dict['returns']
    num_scen = cvar_params.num_scen
    fit_type = cvar_params.fit_type
    
    if fit_type == 'gaussian': # Gaussian distribution
        R_log = np.random.multivariate_normal(return_mean, covariance, size = num_scen)
        R = np.transpose(R_log)
        p = np.ones(num_scen) / num_scen # probability of each scenario

    elif fit_type == 'kde': # kde distribution
        R_log = generate_samples_kde(num_scen, returns_data, bandwidth=0.005, kernel='gaussian', device = device)
        R = np.transpose(R_log)
        p = np.ones(num_scen) / num_scen #probability of each scenario

    elif fit_type == 'no_fit': # use input data directly 
        R = np.transpose(returns_data)
        num_scen = R.shape[1]
        p = np.ones(num_scen) / num_scen
        cvar_params.update_num_scen(num_scen)
    else: 
        raise ValueError('Unsupported fit type: must be from gaussian, kde, or no_fit.')
        
    cvar_data = cvar_optimizer.CVaR_Data(mean = return_mean,
                     covariance = covariance,
                     R = R,
                     p = p)
    
    returns_dict['cvar_data'] = cvar_data
    
    return returns_dict


def optimize_market_regimes(input_file_name, return_type, all_regimes, cvar_params, problem_from_folder = None,
                            gpu_settings = None, cpu_settings = None, device = 'CPU', results_csv_file_name = None,
                            num_synthetic = 0): 
    '''
    compare the performance of cuOpt linear solver vs. CPU across different regimes. Output files to send to cuOpt solver. 
    
    Params: 
    :input_file_name: str
    :return_type: str - type of returns, ex. LOG
    :all_regimes: dict - recording different regimes to test; format: {'regime_name': regime_range}
    :cvar_params: CVaR_Parameters class - relevant CVaR optimization parameters
    :problem_from_folder: str - None if setting up problem from scratch, else the folder of the files to find the optimization problems.
    :device: str - CPU, GPU, or BOTH
    :gpu_tolerance: float - tolerance level for cuopt linear solver (see details in cuOpt documentation)
    :cpu_settings: bool - cpu solver
    :results_csv_file_name: str - csv filename to save the results
    :num_synthetic: int - number of copies of synthetic data to generate. 0 means no generation. 
    '''
    device = device.upper() 
    if device == 'CPU' or device == 'GPU': #solve on single device
        columns = ['device', 'regime', 'solve time', 'obj', 'return', 'CVaR', 'optimal portfolio']
        result_dataframe = pd.DataFrame(columns=columns)
    elif device == 'BOTH': #solve on both device for comparison
        columns = ['regime', 'cpu_time', 'gpu_time', 'obj_gap(CPU - GPU)', 'return_gap', 'CVaR_gap', 'cpu optimal portfolio', 'gpu optimal portfolio']
        result_dataframe = pd.DataFrame(columns=columns)
    
    for regime_name, regime_range in all_regimes.items():
        print("========================================")
        
        if num_synthetic > 0: #create synthetic datasets on the fly
            input_data_directory = create_synthetic_stock_dataset(input_file_name, regime_name, regime_range, num_synthetic)
        else:
            input_data_directory = input_file_name
            
        # create the returns_dict for the current regime
        curr_regime = {'name': regime_name, 'range': regime_range}
        returns_dict = calculate_returns(input_data_directory, curr_regime, return_type, cvar_params)
        
        # set-up optimization problem
        if problem_from_folder is None: 
            cvar_problem = cvar_optimizer.CVaR(returns_dict = returns_dict, cvar_params = cvar_params)
        else: 
            if not os.path.isdir(problem_from_folder):
                raise FileNotFoundError(f"The directory '{directory}' does not exist or is not a directory.")
            else: 
                problem_from_file = problem_from_folder + "/" + regime_name + '-' + 'num_scen' + str(cvar_params.num_scen)
            
            cvar_problem = cvar_optimizer.CVaR(returns_dict = returns_dict, cvar_params = cvar_params, problem_from_file = problem_from_file)
            
        if device != 'BOTH': 
            # solve problem on specified device
            result, portfolio = cvar_problem.solve_optimization_problem(device = device, cpu_settings = cpu_settings, gpu_settings = gpu_settings)
            
            result['optimal portfolio'] = portfolio.print_clean(verbose=False)
            result['device'] = device
            result_dataframe = pd.concat([result_dataframe, result.to_frame().T])

        
        else: #solve on both CPU and GPU
            #solve on CPU
            cpu_result, cpu_portfolio = cvar_problem.solve_optimization_problem(device = 'CPU', cpu_settings = cpu_settings, gpu_settings = gpu_settings)
            
            #solve on GPU
            gpu_result, gpu_portfolio = cvar_problem.solve_optimization_problem(device = 'GPU', cpu_settings = cpu_settings, gpu_settings = gpu_settings)
            
            result = pd.Series({'regime': regime_name, 'cpu_time': cpu_result['solve time'], 'gpu_time': gpu_result['solve time'], 'obj_gap(CPU - GPU)': cpu_result['obj'] - gpu_result['obj'],\
                     'return_gap': cpu_result['return'] - gpu_result['return'], 'CVaR_gap': cpu_result['CVaR'] - gpu_result['CVaR']})
            result['cpu optimal portfolio'] = cpu_portfolio.print_clean(verbose=False)
            result['gpu optimal portfolio'] = gpu_portfolio.print_clean(verbose=False)            
            result_dataframe = pd.concat([result_dataframe, result.to_frame().T])
            
            
    result_dataframe.reset_index(drop = True, inplace = True)

    if results_csv_file_name: 
        result_dataframe.to_csv(results_csv_file_name)

    return result_dataframe

def create_synthetic_stock_dataset(training_directory, regime_name, regime_range, num_synthetic):
    if num_synthetic <= 0:
        raise ValueError('Please provide a valid integer for num_synthetic!')

    synthetic_data = scenario_generation.generate_synthetic_stock_data(dataset_directory=training_directory,\
                                                           num_synthetic=num_synthetic,\
                                                           fit_range = regime_range,\
                                                           generate_range = regime_range)
    dataset_size = len(synthetic_data.columns)

    save_name = 'synthetic-' + regime_name + f'-size_{dataset_size}.csv'
    save_path = os.path.join(os.path.dirname(training_directory), save_name)
    synthetic_data.to_csv(save_path)

    return save_path


def generate_file_market_regimes(input_file_name, return_type, all_regimes, cvar_params, folder_name = None): 
    '''
    generate the files for cuOpt without solving the problems 
    '''
    if folder_name is None: 
        raise ValueError('Need to provide a folder directory!')
    else: 
        os.makedirs(folder_name, exist_ok=True)
        
    for regime_name, regime_range in all_regimes.items():
        curr_regime = {'name': regime_name, 'range': regime_range}
        returns_dict = calculate_returns(input_file_name, curr_regime, return_type, cvar_params)
        
        cvar_problem = cvar_optimizer.CVaR(returns_dict = returns_dict, cvar_params = cvar_params)
        
        file_name = regime_name + '-num_scen' + str(cvar_params.num_scen)
        to_file = (folder_name, file_name)
            
        cvar_problem._save_problem_for_cuopt(to_file)
        print(f'File generated at: {folder_name}/{file_name}' + FILE_FORMAT)

def convert_to_compliant(value):
    '''
    Helper function to convert values to format for cuOpt
    '''
    if isinstance(value, float):
        if np.isnan(value):
            return 'NaN'
        elif np.isinf(value):
            if value > 0:
                return 'inf'
            else:
                return 'ninf'
    return value

def convert_from_file(value):
    if value == 'inf':
        return np.inf
    elif value == 'ninf':
        return -np.inf
    else: 
        return value

def evaluate_portfolio_performance(cvar_data, portfolio, confidence_level):
    '''
    evaluate non-optimized portfolios from input
    Params: 
    :cvar_data: CVaR_Data dataclass.
    :weight_dict: dict - {ticker: weight}
    '''
    portfolio_expected_return = portfolio.calculate_portfolio_expected_return(cvar_data.mean)
    portfolio_variance = portfolio.calculate_portfolio_variance(cvar_data.covariance)
    portfolio_CVaR = compute_CVaR(cvar_data, portfolio.weights, confidence_level)

    return {'portfolio': portfolio, 'return': portfolio_expected_return, 'variance': portfolio_variance, 'CVaR': portfolio_CVaR}

def compute_CVaR(cvar_data, weights, confidence_level): 
    '''
    compute the CVaR of a given portfolio
    
    Params: 
    :cvar_data: CVaR_Data dataclass. 
    :weights: numpy array (n_assets, )
    :confidence_level: 
    '''
    portfolio_returns = cvar_data.R.T @ weights
    VaR = np.percentile(portfolio_returns, (1-confidence_level)*100)
    tail_loss = portfolio_returns[portfolio_returns <= VaR]
    CVaR = np.abs(np.mean(tail_loss))

    return CVaR

def evaluate_single_asset_portfolios(cvar_problem):
    '''
    create a dataframe where each row records the performance of a portfolio consisting of one stock. 
    
    Params:
    :cvar_problem: CVaR class - optimization problem
    
    Return:
    :single_asset_portfolio_performance: dataframe with columns ['portfolio', 'return', 'variance', 'CVaR']
    '''
    single_asset_portfolio_performance = pd.DataFrame([], dtype = np.float64, index = cvar_problem.tickers,\
                                                      columns = ['portfolio', 'return', 'variance', 'CVaR'])

    for idx, ticker in enumerate(cvar_problem.tickers):
        portfolio_name = ticker + '_single_portfolio'
        weights_dict = {ticker: cvar_problem.params.w_max}
        cash = 1 - cvar_problem.params.w_max
        
        portfolio = Portfolio(tickers=cvar_problem.tickers, time_range = cvar_problem.regime_range)
        portfolio.portfolio_from_dict(portfolio_name, weights_dict, cash)
        
        portfolio_performance = evaluate_portfolio_performance(cvar_problem.data, portfolio, cvar_problem.params.confidence)
        single_asset_portfolio_performance.loc[ticker] = portfolio_performance
    
    return single_asset_portfolio_performance

def generate_user_input_portfolios(portfolios_dict, returns_dict, existing_portfolios = []):
    '''
    create portfolios from user inputs
    
    Params: 
    ``portfolios_dict`` dict of dictionaries - dictionary of weight dictionaries and cash {custom portfolio name: (weight dictionary, cash)}
    ``returns_dict`` dict - dictionary of all returns info
    ``exisiting_portfolios`` list - portfolios from previous inputs
    '''
    if isinstance(existing_portfolios, pd.DataFrame):
        if not existing_portfolios.empty:
            existing_portfolios = existing_portfolios['portfolio'].tolist()
        else: 
            existing_portfolios = []
            
    elif isinstance(existing_portfolios, list):
        pass
    else: 
        raise ValueError('Existing portfolios type not supported - it has to be a list of Portfolios or a DataFrame with portfolio performance.')
        
    for portfolio_name, portfolio_tuple in portfolios_dict.items():
        
        weights_dict, cash = portfolio_tuple
        portfolio = Portfolio(tickers=returns_dict['tickers'], time_range = returns_dict['regime']['range'])
        portfolio.portfolio_from_dict(portfolio_name, weights_dict, cash)
        
        existing_portfolios.append(portfolio)
    
    return existing_portfolios

def evaluate_user_input_portfolios(cvar_problem, portfolios_dict, returns_dict,
                                   custom_portfolios=pd.DataFrame([], columns = ['portfolio_name', 'portfolio', 'return', 'variance', 'CVaR'])):
    '''
    create a dataframe of portfolios from user inputs with performance metrics (used for plotting efficient frontier or simple comparison)

    Params: 
    :portfolios_dict: dict of dictionaries - dictionary of weight dictionaries and cash {custom portfolio name: (weight dictionary, cash)}
    :returns_dict: dict - dictionary of all returns info
    :custom_portfolios: dataframe - (optional) existing custom portfolios
    '''
    existing_portfolios = generate_user_input_portfolios(portfolios_dict, returns_dict, custom_portfolios)
    
    for portfolio in existing_portfolios:
        portfolio_performance = evaluate_portfolio_performance(cvar_problem.data, portfolio, cvar_problem.params.confidence)
        portfolio_performance['portfolio_name'] = portfolio.name
        
        portfolio_dataframe = pd.Series(portfolio_performance, index = custom_portfolios.columns).to_frame().T
        if custom_portfolios.shape[0] > 0:
            if portfolio.name not in custom_portfolios['portfolio_name'].values:
                custom_portfolios = pd.concat([custom_portfolios, portfolio_dataframe], ignore_index = False)
            else:
                    print(f"{portfolio_dataframe['portfolio_name'].values} already exists or please change to a different portfolio name.")
        else: 
            custom_portfolios = portfolio_dataframe
            
    custom_portfolios.reset_index(drop = True, inplace = True)
    
    return custom_portfolios

def generate_efficient_frontier(returns_dict, cvar_params, \
                            device = 'CPU', gpu_settings = None, cpu_settings = {'verbose': False},\
                            folder_name = None, key_portfolios = 'default', opt_result_verbose = False, custom_portfolios_dict = {},\
                            title = None, EF_result_csv_name = None, \
                            EF_plot_png_name = None, show_plot = True, min_risk_aversion = -2, max_risk_aversion = 0.5, ra_num = 5):
    
        '''
        Params: 
        :returns_dict: returns information
        :cvar_params: CVaR_Parameters class - relevant CVaR optimization parameters
        :fit_type: str - fit return data to type (Gaussian, kde, historical, etc.)
        :device: str - CPU solver or GPU solver
        :gpu_tolerance: float - tolerance level for cuopt linear solver (see details in cuOpt documentation)
        :cpu_settings: bool - verbose cpu solver
        :key_portfolios: dict - {portfolio_name: marker} the dictionary of key portfolio names and their corresponding markers to show on efficient frontier
        :title: str - title of the plot (if None, then default title)
        :EF_result_csv_name: str - path to save the EF_result using CPU solver
        :plot_fig: bool - whether to display the EF figure
        :EF_plot_png_name: str - save the efficient frontier figure under the name EF_plot_png_name
        :min_risk_aversion: float - start of the logspace for risk aversions
        :max_risk_aversion: float - end of the logspace for risk aversions
        :ra_num: int - number of risk aversions in the logspace
        '''
        
        device = device.upper()
        
        if key_portfolios == 'default': #default key portfolios
            key_portfolios = dict(zip(['Min_Var', 'Max_Sharpe', 'Max_Return'],['*', 'o', 'D']))
            
        columns = ['regime', "solve time", "return", 'CVaR', "obj", "optimal portfolio", "risk"]
        result_dataframe = pd.DataFrame([], columns=columns)
        
        #initialize the cvar optimization problem
        cvar_problem = cvar_optimizer.CVaR(returns_dict = returns_dict, cvar_params = cvar_params)
        
        if custom_portfolios_dict:
            custom_portfolios = evaluate_user_input_portfolios(cvar_problem, custom_portfolios_dict, returns_dict)
            
        #generate the single-asset portfolios
        single_asset_portfolios = evaluate_single_asset_portfolios(cvar_problem)
        
        #generate risk_aversion 
        risk_aversion_list = np.logspace(start = min_risk_aversion, stop = max_risk_aversion, num = ra_num)[::-1].round(5)

        for ra_value in risk_aversion_list: 
            cvar_problem.params.update_risk_aversion(ra_value)
            cvar_problem._set_up() #re-set-up the problem
            
            if device == 'GPU' and folder_name is not None:
                    file_name = returns_dict['regime']['name'] + '-num_scen'\
                                + str(cvar_params.num_scen) + '-risk_aversion' + str(round(ra_value,2))
                
                    to_file = (folder_name, file_name)
                
            else:
                to_file = None

            
            result_row, portfolio = cvar_problem.solve_optimization_problem(device = device, gpu_settings = gpu_settings, cpu_settings = cpu_settings, to_file = to_file, print_result = False)
            
            result_row['risk'] = portfolio.calculate_portfolio_variance(cvar_problem.data.covariance)
            result_row['optimal portfolio'] = portfolio.print_clean()
            
            result_dataframe = pd.concat([result_dataframe, result_row.to_frame().T], ignore_index = True)

        result_dataframe['sharpe'] = result_dataframe['return'] / result_dataframe['CVaR']
        
        if EF_result_csv_name: 
            result_dataframe.to_csv(EF_result_csv_name)
        
        #plot/save efficient frontier
        utils.plot_efficient_frontier('CVaR', result_dataframe, single_asset_portfolios, custom_portfolios, key_portfolios, opt_result_verbose, title, show_plot, EF_plot_png_name)
        return result_dataframe
