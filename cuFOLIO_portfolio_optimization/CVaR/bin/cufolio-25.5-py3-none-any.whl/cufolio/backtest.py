"""
SPDX-FileCopyrightText: Copyright (c) 2021-2025 NVIDIA CORPORATION &
AFFILIATES. All rights reserved. SPDX-License-Identifier:
LicenseRef-NvidiaProprietary

NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
property and proprietary rights in and to this material, related
documentation and any modifications thereto. Any use, reproduction,
disclosure or distribution of this material and related documentation
without an express license agreement from NVIDIA CORPORATION or
its affiliates is strictly prohibited.
"""

"""Module for portfolio backtesting using historical, KDE, or Gaussian return scenarios."""

import numpy as np
import pandas as pd
from sklearn.neighbors import KernelDensity

import matplotlib.pyplot as plt
import seaborn as sns

from . import cvar_utils, utils
from .portfolio import Portfolio

class portfolio_backtester:
    """
    Backtester for evaluating a given portfolio against benchmarks.

    Supports:
      - Historical backtest (uses actual historical returns).
      - Simulation via Gaussian or Kernel Density Estimation (KDE).
      - Performance metrics: Sharpe, Sortino, max drawdown.
      - Plotting cumulative return paths.

    Attributes:
        test_portfolio (Portfolio): The primary portfolio under test.
        test_method (str): One of 'historical', 'kde_simulation', 'gaussian_simulation'.
        _historical_dates_index (pd.DatetimeIndex): Reference dates for historical data.
        _historical_asset_returns_df_std (pd.DataFrame): Standardized returns DataFrame.
        _historical_asset_returns_numpy (np.ndarray): Historical returns as NumPy array.
        _return_type (str): 'LOG' or 'LINEAR'.
        risk_free_rate (float): Per-period risk-free rate (log or linear).
        _R (np.ndarray): Return scenarios (historical or simulated).
        benchmark_portfolios (list[Portfolio]): List of benchmark Portfolio objects.
        _backtest_column_names (list[str]): Column names for backtest results DataFrame.
    """
    def __init__(self, test_portfolio, returns_dict, risk_free_rate=0.0, test_method='historical', benchmark_portfolios=None):
        """
        Initialize the backtester with portfolio, returns data, and parameters.

        Args:
            test_portfolio (Portfolio): Portfolio to be backtested.
            returns_dict (dict): Dictionary containing:
                - 'dates': pd.Index or convertible to pd.DatetimeIndex.
                - 'returns': pd.DataFrame of asset returns.
                - 'tickers': list of asset ticker strings.
                - 'return_type': 'LOG' or 'LINEAR'.
                - 'mean': array-like mean returns (required for Gaussian).
                - 'covariance': covariance matrix (required for Gaussian).
            risk_free_rate (float, optional): Risk-free rate per period. Defaults to 0.0.
            test_method (str, optional): One of 'historical', 'kde_simulation', 'gaussian_simulation'.
            benchmark_portfolios (list or pd.DataFrame, optional): Extra benchmarks.

        Raises:
            TypeError: If 'dates', 'returns', or 'tickers' are wrong types.
            ValueError: If data lengths mismatch or conversion errors.
        """
        self.test_portfolio = test_portfolio
        self.test_method = test_method.lower()
        self.input_returns_dict = returns_dict # Keep original dict for reference

        # 1. Establish authoritative DatetimeIndex for historical data
        raw_dates_input = self.input_returns_dict.get('dates')
        if not isinstance(raw_dates_input, pd.Index):
            raise TypeError(f"returns_dict['dates'] must be a pandas Index. Got: {type(raw_dates_input)}")
        
        if isinstance(raw_dates_input, pd.DatetimeIndex):
            self._historical_dates_index = raw_dates_input
        else: # Convert generic Index (e.g., ints or strings) to DatetimeIndex
            try:
                self._historical_dates_index = pd.to_datetime(raw_dates_input)
                if not isinstance(self._historical_dates_index, pd.DatetimeIndex): # Check after conversion attempt
                    raise ValueError("Failed to convert returns_dict['dates'] to a valid DatetimeIndex.")
            except Exception as e:
                raise ValueError(f"Error converting returns_dict['dates'] to DatetimeIndex: {e}")
        # Store Python datetime list for any functionality needing list of datetimes
        self._dates_list = self._historical_dates_index.to_pydatetime().tolist()

        # 2. Validate and extract historical asset returns DataFrame
        historical_asset_returns_df_input = self.input_returns_dict.get('returns')
        if not isinstance(historical_asset_returns_df_input, pd.DataFrame):
            raise TypeError(f"returns_dict['returns'] must be a pandas DataFrame. Got: {type(historical_asset_returns_df_input)}")

        # 3. Validate and extract asset tickers list
        self._asset_tickers_in_order = self.input_returns_dict.get('tickers')
        if not isinstance(self._asset_tickers_in_order, list):
            raise TypeError(f"returns_dict['tickers'] must be a list. Got: {type(self._asset_tickers_in_order)}")

        # 4. Standardize the DataFrame: align index and columns
        # Ensure its index is self._historical_dates_index and columns match self._asset_tickers_in_order.
        if len(historical_asset_returns_df_input) != len(self._historical_dates_index):
            raise ValueError(
                f"Row length of returns_dict['returns'] DataFrame ({len(historical_asset_returns_df_input)}) "
                f"does not match length of returns_dict['dates'] Index ({len(self._historical_dates_index)})."
            )
        
        try: # Reorder columns to match tickers and set index to DatetimeIndex
            self._historical_asset_returns_df_std = historical_asset_returns_df_input[self._asset_tickers_in_order].copy()
            self._historical_asset_returns_df_std.index = self._historical_dates_index
        except KeyError as e:
            raise ValueError(f"One or more tickers from returns_dict['tickers'] not found in columns of returns_dict['returns'] DataFrame. Missing: {e}")
        except Exception as e:
            raise ValueError(f"Error standardizing historical_asset_returns_df: {e}")

        # Convert standardized DataFrame to NumPy for fast simulation
        self._historical_asset_returns_numpy = self._historical_asset_returns_df_std.to_numpy()

        if len(self._asset_tickers_in_order) != self._historical_asset_returns_numpy.shape[1]:
            raise ValueError(
                f"Internal Consistency Error: Number of asset tickers ({len(self._asset_tickers_in_order)}) "
                f"does not match columns in processed numpy asset returns ({self._historical_asset_returns_numpy.shape[1]})."
            )

        # Extract return distribution parameters
        self._return_type = self.input_returns_dict.get('return_type')
        if self._return_type is None:
            raise ValueError("returns_dict must contain 'return_type'.")

        self._return_mean_fit = self.input_returns_dict.get('mean') 
        self._covariance_fit = self.input_returns_dict.get('covariance')

        # Generate the return scenarios matrix (historical or simulated)
        self._R = self._get_return_scenarios()

        # Prepare benchmark portfolios (equal-weight default or provided)
        self.benchmark_portfolios = self._generate_benchmark_portfolios(benchmark_portfolios)

        # Convert risk-free rate to log if necessary
        if self._return_type == 'LOG':
            # allow -1 for 100% loss on cash
            self.risk_free_rate = np.log(1 + risk_free_rate) if risk_free_rate >= -1 else risk_free_rate # allow -1 for 100% loss
        elif self._return_type == 'LINEAR':
            self.risk_free_rate = risk_free_rate
        else:
            self.risk_free_rate = risk_free_rate 
            print(f"Warning: Unknown return type '{self._return_type}'. Using risk_free_rate as is.")

        # Column names used for backtest results
        self._backtest_column_names = ['returns', 'cumulative returns', 'portfolio name', 
                                     'mean portfolio return', 'sharpe', 'sortino', 'max drawdown']
        
    def _generate_benchmark_portfolios(self, benchmark_portfolios_input):
        """
        Build or validate benchmark portfolio list.

        Args:
            benchmark_portfolios_input (None, list[Portfolio], or pd.DataFrame): 
                If None, create equal-weight portfolio from test_portfolio.
                If DataFrame, expects a 'portfolio' column with Portfolio objects.
                If list, must be list of Portfolio.
        Returns:
            list[Portfolio]: List of benchmark portfolios.
        Raises:
            ValueError: If input format is not recognized.
        """
        if benchmark_portfolios_input is None: # Default: equal-weight of test_portfolio tickers
            if self.test_portfolio and hasattr(self.test_portfolio, 'tickers') and self.test_portfolio.tickers:
                 return self._generate_equal_weights_portfolio(self.test_portfolio.tickers, getattr(self.test_portfolio, 'cash', 0.0))
            return [] # No benchmarks
        if isinstance(benchmark_portfolios_input, pd.DataFrame): # Expect column 'portfolio' containing Portfolio objects
            return benchmark_portfolios_input['portfolio'].to_list() if 'portfolio' in benchmark_portfolios_input else []
        if isinstance(benchmark_portfolios_input, list): # Already a list of Portfolio objects
            return benchmark_portfolios_input
        raise ValueError('Unacceptable benchmark_portfolios format. Provide DataFrame or list of Portfolio objects.')

    def _generate_equal_weights_portfolio(self, tickers, cash):
        """
        Create an equal-weighted Portfolio.

        Args:
            tickers (list[str]): Asset tickers.
            cash (float): Cash weight fraction [0,1].
        Returns:
            list[Portfolio]: Single-element list containing the Portfolio.
        """
        n_assets = len(tickers)
        if n_assets == 0: # All cash if no assets
            return [Portfolio(name='equal-weight', tickers=[], weights={}, cash=1.0)]
        asset_investment_fraction = 1.0 - cash
        # Ensure asset_investment_fraction is not negative
        asset_investment_fraction = max(0.0, asset_investment_fraction)

        weights_values = np.full(n_assets, asset_investment_fraction / n_assets)
        weights_dict = {ticker: weights_values[i] for i, ticker in enumerate(tickers)}
        eq_weight_portfolio = Portfolio(name='equal-weight', tickers=tickers, weights=weights_dict, cash=cash)
        return [eq_weight_portfolio]
        
    def _generate_simulated_scenarios(self, generation_method='kde', num_scen=5000):
        """
        Simulate return scenarios via Gaussian or KDE.

        Args:
            generation_method (str): 'gaussian' or 'kde'.
            num_scen (int): Number of scenarios to simulate.
        Returns:
            np.ndarray: Simulated returns array of shape (num_scen, n_assets).
        Raises:
            ValueError, NotImplementedError: For missing parameters or invalid method.
        """
        generation_method = str(generation_method).lower()
        if generation_method == 'gaussian': # Requires pre-computed mean and covariance
            if self._return_mean_fit is None or self._covariance_fit is None:
                raise ValueError("Mean and covariance must be provided in returns_dict for Gaussian simulation.")
            R_sim = np.random.multivariate_normal(self._return_mean_fit, self._covariance_fit, size=num_scen)
        elif generation_method == 'kde': # Fit KDE on historical returns
            if self._historical_asset_returns_numpy is None or self._historical_asset_returns_numpy.ndim != 2 or self._historical_asset_returns_numpy.shape[0] == 0:
                raise ValueError("Valid historical asset returns (numpy array) required for KDE fitting.")
            R_sim = self._generate_samples_kde(self._historical_asset_returns_numpy, num_scen, bandwidth=0.005)
        else:
            raise NotImplementedError(f"Invalid Generation Method: {generation_method}")
        return R_sim

    def _generate_samples_kde(self, returns_data_numpy, num_scen, bandwidth, kernel='gaussian'):
        """
        Draw samples from a fitted Kernel Density Estimator.

        Args:
            returns_data_numpy (np.ndarray): Historical returns data.
            num_scen (int): Number of samples to draw.
            bandwidth (float): KDE bandwidth.
            kernel (str): Kernel type for sklearn.KernelDensity.
        Returns:
            np.ndarray: New samples of shape (num_scen, n_assets).
        """
        kde = KernelDensity(kernel=kernel, bandwidth=bandwidth).fit(returns_data_numpy)
        new_samples = kde.sample(num_scen)
        return new_samples
        
    def _get_return_scenarios(self):
        """
        Select or simulate return scenarios based on test_method.

        Returns:
            np.ndarray: Return scenarios matrix.
        Raises:
            NotImplementedError: For invalid test_method.
        """
        if self.test_method == 'historical':
            R_scen = self._historical_asset_returns_numpy
        elif self.test_method == 'kde_simulation':
            R_scen = self._generate_simulated_scenarios(generation_method='kde')
        elif self.test_method == 'gaussian_simulation':
            R_scen = self._generate_simulated_scenarios(generation_method='gaussian')
        else:
            raise NotImplementedError(f'Invalid test method: {self.test_method}')
        return R_scen

    def _compute_portfolio_returns_with_cash(self, p_object_weights_attr, p_object_tickers_list):
        """
        Compute portfolio returns including cash component over all scenarios/dates.

        Args:
            p_object_weights_attr (dict or np.ndarray): Asset weightings.
            p_object_tickers_list (list[str]): Corresponding tickers if weights as array.
        Returns:
            np.ndarray: Total asset-component returns (excludes cash).
        Raises:
            TypeError, ValueError: For mismatched weights/tickers or shape inconsistency.
        """
        # Normalize weights into a dict
        portfolio_specific_weights_as_dict = {}
        if isinstance(p_object_weights_attr, dict):
            portfolio_specific_weights_as_dict = p_object_weights_attr
        elif isinstance(p_object_weights_attr, np.ndarray): # Map array entries to tickers
            if not isinstance(p_object_tickers_list, list) or \
               len(p_object_weights_attr) != len(p_object_tickers_list):
                raise ValueError(
                    "If portfolio weights (p_object_weights_attr) are a numpy array, "
                    "portfolio tickers (p_object_tickers_list) must be a list of corresponding tickers and match in length."
                )
            portfolio_specific_weights_as_dict = {
                ticker: p_object_weights_attr[i] for i, ticker in enumerate(p_object_tickers_list)
            }
        else:
            raise TypeError(
                f"Portfolio weights attribute must be a dict or numpy array, got {type(p_object_weights_attr)}"
            )

        # Align weights array to columns order of self._R
        weights_array_aligned_with_R = np.array([
            portfolio_specific_weights_as_dict.get(ticker, 0.0) for ticker in self._asset_tickers_in_order
        ])

        # Ensure shape consistency
        if self._R.shape[1] != len(weights_array_aligned_with_R):
            raise ValueError(
                f"Shape mismatch: Number of assets in self._R (columns: {self._R.shape[1]}, based on "
                f"{len(self._asset_tickers_in_order)} tickers defined in __init__) "
                f"does not match number of constructed portfolio weights ({len(weights_array_aligned_with_R)}). "
                f"This may be due to inconsistencies between tickers in returns_dict and portfolio definitions."
            )
                             
        # Compute dot-product: scenarios/dates x weights
        portfolio_asset_component_returns = self._R @ weights_array_aligned_with_R
        return portfolio_asset_component_returns

    def _compute_return_metrics(self, portfolio_name, asset_component_returns, portfolio_cash_weight):
        """
        Derive performance metrics and series for a single portfolio.

        Args:
            portfolio_name (str): Name identifier.
            asset_component_returns (np.ndarray or pd.Series): Returns from non-cash assets.
            portfolio_cash_weight (float): Fraction allocated to cash.
        Returns:
            pd.DataFrame: Single-row backtest summary with columns:
                ['returns','cumulative returns','portfolio name',
                 'mean portfolio return','sharpe','sortino','max drawdown']
        Raises:
            ValueError: For unsupported return types in cumulative calc.
        """
        # Calculate mean return of risky assets
        mean_asset_component_return = np.mean(asset_component_returns)
        # Add cash contribution
        mean_total_portfolio_return = mean_asset_component_return + portfolio_cash_weight * self.risk_free_rate

        # Build full return series including cash
        total_portfolio_returns_series = asset_component_returns + portfolio_cash_weight * self.risk_free_rate
        # Excess returns relative to risk-free
        excess_total_portfolio_returns = total_portfolio_returns_series - self.risk_free_rate

        # Compute cumulative growth factor based on return type
        if self._return_type == 'LINEAR':
            # Cumulative returns of the *total portfolio*
            cumulative_total_portfolio_returns_val = np.cumsum(total_portfolio_returns_series)
            # To represent as growth factor from 1: 1 + cumsum(simple_returns)
            cumulative_growth_factor = 1 + cumulative_total_portfolio_returns_val if len(total_portfolio_returns_series) > 0 else np.array([1.0])

        elif self._return_type == 'LOG':
            # Cumulative returns of the *total portfolio*
            # If total_portfolio_returns_series are already log returns of total portfolio:
            cumulative_total_portfolio_returns_val = np.exp(np.cumsum(total_portfolio_returns_series))
            cumulative_growth_factor = cumulative_total_portfolio_returns_val # This is already the growth factor
        else:
            raise ValueError(f"Unsupported return type: {self._return_type} for cumulative returns calculation.")

        # Compute risk-adjusted metrics
        sharpe = self.sharpe_ratio(excess_total_portfolio_returns)
        sortino = self.sortino_ratio(excess_total_portfolio_returns)
        # Max drawdown is calculated on the cumulative growth factor of the total portfolio
        mdd = self.max_drawdown(cumulative_growth_factor) 
        
        returns_data_for_series = total_portfolio_returns_series.to_numpy() if isinstance(total_portfolio_returns_series, pd.Series) else total_portfolio_returns_series
        cumulative_data_for_series = cumulative_growth_factor.to_numpy() if isinstance(cumulative_growth_factor, pd.Series) else cumulative_growth_factor
        
        result = pd.Series([
            returns_data_for_series,       # Daily/scenario total portfolio returns
            cumulative_data_for_series,    # Cumulative total portfolio growth factor
            portfolio_name, 
            mean_total_portfolio_return,   # Mean of total portfolio returns
            sharpe,                        # Sharpe of total portfolio
            sortino,                       # Sortino of total portfolio
            mdd                            # Max drawdown of total portfolio
        ], index=self._backtest_column_names)
        
        return result.to_frame().T

    def backtest_single_portfolio(self, portfolio_object):
        """
        Run backtest for one Portfolio instance.

        Args:
            portfolio_object (Portfolio): Portfolio to test.
        Returns:
            pd.DataFrame: Backtest summary row for this portfolio.
        Raises:
            TypeError: If argument is not a Portfolio.
        """
        if not isinstance(portfolio_object, Portfolio):
            raise TypeError(f"Expected a Portfolio object, got {type(portfolio_object)}")
        
        # Get asset returns component
        asset_component_returns = self._compute_portfolio_returns_with_cash(
            portfolio_object.weights,    # This is p_object_weights_attr
            portfolio_object.tickers     # This is p_object_tickers_list
        )
        
        # Compute metrics including cash
        backtest_result_df = self._compute_return_metrics(
            portfolio_object.name, 
            asset_component_returns, 
            portfolio_object.cash        # This is portfolio_cash_weight for _compute_return_metrics
        )
        return backtest_result_df

    def backtest_against_benchmarks(self, plot_returns=False, ax=None, cut_off_date=None, title=None):
        """
        Backtest test_portfolio and benchmarks, optionally plotting cumulative paths.

        Args:
            plot_returns (bool): Whether to plot cumulative return lines.
            ax (matplotlib.axes.Axes, optional): Pre-existing axes to draw on.
            cut_off_date (str or datetime, optional): Vertical line cutoff in plot.
            title (str, optional): Title for plot.
        Returns:
            tuple(pd.DataFrame, matplotlib.axes.Axes):
                - DataFrame indexed by portfolio name with metrics.
                - Axes object (None if plotting disabled).
        """
        results_list = []
        
        # Backtest main portfolio first
        if self.test_portfolio:
            df_optimal = self.backtest_single_portfolio(self.test_portfolio)
            results_list.append(df_optimal)

        # Backtest each benchmark
        for portfolio_obj in self.benchmark_portfolios:
            if portfolio_obj:
                df_benchmark = self.backtest_single_portfolio(portfolio_obj)
                results_list.append(df_benchmark)

        # If no portfolios to backtest
        if not results_list:
            backtest_results = pd.DataFrame(columns=self._backtest_column_names)
            if 'portfolio name' in self._backtest_column_names:
                 backtest_results = backtest_results.set_index('portfolio name')
            if ax is None and plot_returns:
                 _, ax = plt.subplots(figsize=(10, 7))
            return backtest_results, ax

        # Concatenate results and set index
        backtest_results = pd.concat(results_list, ignore_index=True) 
        if 'portfolio name' in backtest_results.columns:
            backtest_results.set_index('portfolio name', inplace=True)
        else:
            print("Warning: 'portfolio name' column not found. Cannot set index by portfolio name.")

        # Plot cumulative return series if requested
        if plot_returns:            
            if ax is None:
                _ , ax = plt.subplots(figsize=(10, 7))

            plot_datetime_index = None
            if hasattr(self, '_historical_dates_index') and isinstance(self._historical_dates_index, pd.DatetimeIndex):
                plot_datetime_index = self._historical_dates_index
            
            if plot_datetime_index is None:
                ax.text(0.5, 0.5, "Internal Error: Historical DatetimeIndex for plotting is not available.",
                        ha='center', va='center', transform=ax.transAxes, fontsize=9, color='red')
                return backtest_results, ax

            cumulative_returns_for_plot_df = pd.DataFrame(index=plot_datetime_index)
            plotted_any_lines = False

            for ptf_name, row_data in backtest_results.iterrows():
                if self.test_method == 'historical':
                    # For historical, 'cumulative returns' column stores the actual path of total portfolio growth factor
                    historical_cumulative_growth_path = row_data['cumulative returns'] 
                    if len(historical_cumulative_growth_path) == len(plot_datetime_index):
                        cumulative_returns_for_plot_df[ptf_name] = historical_cumulative_growth_path
                        plotted_any_lines = True
                    else:
                        print(f"Warning: Length mismatch for historical data of '{ptf_name}'. Cannot plot line.")
                
                elif self.test_method in ['kde_simulation', 'gaussian_simulation']:
                    # For simulation, 'returns' column stores num_scen single-period total portfolio return outcomes
                    simulated_period_returns_outcomes = row_data['returns'] # Array of num_scen outcomes
                    
                    if isinstance(simulated_period_returns_outcomes, np.ndarray) and simulated_period_returns_outcomes.ndim == 1 and len(simulated_period_returns_outcomes) > 0:
                        mean_simulated_period_return = np.mean(simulated_period_returns_outcomes)
                        
                        # Create a synthetic series of these mean returns repeated over the historical period
                        # This Series will have the plot_datetime_index
                        synthetic_mean_returns_series = pd.Series(mean_simulated_period_return, index=plot_datetime_index)
                        
                        # Calculate cumulative growth path from this synthetic mean series
                        if self._return_type == 'LINEAR':
                            # Growth factor for simple returns: (1+r1)*(1+r2)*... = cumulative product of (1+r)
                            synthetic_cumulative_growth = (1 + synthetic_mean_returns_series).cumprod()
                        elif self._return_type == 'LOG':
                            # Growth factor for log returns: exp(r1+r2+...) = exp(cumulative sum of r)
                            synthetic_cumulative_growth = np.exp(synthetic_mean_returns_series.cumsum())
                        else: # Should be caught by __init__ or _compute_return_metrics
                            print(f"Warning: Unsupported return type '{self._return_type}' for plotting mean simulation path for '{ptf_name}'.")
                            continue 

                        cumulative_returns_for_plot_df[f"{ptf_name} (Mean Sim Path)"] = synthetic_cumulative_growth
                        plotted_any_lines = True
                    else:
                        print(f"Warning: Could not plot mean simulation path for '{ptf_name}'. "
                              f"Data in 'returns' column is not a 1D numpy array of scenarios or is empty.")
            
            # Apply seaborn style using a context manager to keep it local to this plot
            with sns.axes_style("whitegrid"):
                sns.set_palette("tab10") # Set palette for the current axes
                if plotted_any_lines:
                    sns.lineplot(data=cumulative_returns_for_plot_df, ax=ax, legend='auto', dashes=False)
                    ax.set_ylabel('Portfolio Value (Cumulative Growth Factor)', fontsize=8) 
                    ax.legend(fontsize=7, title='Portfolio')
                    # ax.grid(True, linestyle='--', alpha=0.7) # whitegrid style includes grid
                else:
                    # This message now applies if neither historical nor mean sim path could be plotted
                    ax.text(0.5, 0.5, "No cumulative return series available for plotting with current method/data.", 
                            ha='center', va='center', transform=ax.transAxes, fontsize=9, 
                            bbox={"facecolor":"lightyellow", "alpha":0.5, "pad":5})

                ax.set_xlabel('Date', fontsize=8)
                ax.tick_params(axis='x', rotation=30, labelsize=7)
                ax.tick_params(axis='y', labelsize=7)
                if title:
                    ax.set_title(title, fontsize=10)
                
                if cut_off_date is not None and plotted_any_lines: # Only draw cut-off if lines are present
                    try:
                        cut_off_datetime = pd.to_datetime(cut_off_date)
                        if plot_datetime_index.min() <= cut_off_datetime <= plot_datetime_index.max():
                            ax.axvline(x=cut_off_datetime, color='dimgrey', linestyle='--', linewidth=1.2, 
                                       label=f'Cut-off: {cut_off_datetime.strftime("%Y-%m-%d")}')
                            if plotted_any_lines: 
                               ax.legend(fontsize=7, title='Portfolio') # Re-apply legend
                        else:
                            print(f"Warning: Cut-off date {cut_off_date} is outside plot's date range.")
                    except Exception as e:
                        print(f"Warning: Could not plot cut-off line for date {cut_off_date}. Error: {e}")
        
        return backtest_results, ax

    def sharpe_ratio(self, excess_total_portfolio_returns):
        """
        Compute annualized Sharpe ratio assuming 252 trading days.

        Args:
            excess_total_portfolio_returns (array-like): Returns in excess of risk-free rate.
        Returns:
            float: Annualized Sharpe ratio (NaN if no volatility, zero-return case handled).
        """
        mean_excess_return = np.mean(excess_total_portfolio_returns)
        std_dev_excess_return = np.std(excess_total_portfolio_returns, ddof=1)
        if std_dev_excess_return == 0: # Avoid div-by-zero: if mean≠0 return NaN, else zero
            return np.nan if mean_excess_return != 0 else 0.0
        # Assuming 252 trading days for annualization, if returns are daily
        sharpe = (mean_excess_return / std_dev_excess_return) * np.sqrt(252) 
        return sharpe

    def sortino_ratio(self, excess_total_portfolio_returns):
        """
        Compute annualized Sortino ratio (downside-volatility adjusted).

        Args:
            excess_total_portfolio_returns (array-like): Returns in excess of risk-free rate.
        Returns:
            float: Annualized Sortino ratio (∞ if no downside, zero-case handled).
        """
        mean_excess_return = np.mean(excess_total_portfolio_returns)
        downside_returns = excess_total_portfolio_returns[excess_total_portfolio_returns < 0]
        if len(downside_returns) == 0: # No downside returns
            return np.inf if mean_excess_return > 0 else 0.0 # Or np.nan
        
        downside_deviation = np.std(downside_returns, ddof=1)
        if downside_deviation == 0: # No downside volatility
            return np.inf if mean_excess_return > 0 else 0.0 # Or np.nan
            
        sortino = (mean_excess_return / downside_deviation) * np.sqrt(252) # Annualized
        return sortino

    def max_drawdown(self, cumulative_growth_factor):
        """
        Calculate maximum drawdown from a growth factor series.

        Args:
            cumulative_growth_factor (array-like): Portfolio value path over time.
        Returns:
            float: Maximum drawdown as a positive fraction.
        """
        # cumulative_growth_factor represents total portfolio value over time (e.g., starting at 1)
        if not isinstance(cumulative_growth_factor, np.ndarray):
            cumulative_growth_factor = np.array(cumulative_growth_factor)
        if len(cumulative_growth_factor) == 0:
            return 0.0

        portfolio_values = cumulative_growth_factor
        running_max = np.maximum.accumulate(portfolio_values)
        
        # Prevent division by zero if running_max can be zero (e.g. if portfolio value can go to 0)
        # For a typical growth factor starting at 1, running_max will be >= 1.
        # However, if portfolio_values can be 0 or negative, this needs care.
        # Let's assume portfolio_values are always positive.
        drawdown = (portfolio_values - running_max) / running_max     # Drawdown is negative or zero
        max_dd_value = np.min(drawdown) if len(drawdown) > 0 else 0.0 # Most severe drawdown
        
        return abs(max_dd_value) # Reported as a positive value
