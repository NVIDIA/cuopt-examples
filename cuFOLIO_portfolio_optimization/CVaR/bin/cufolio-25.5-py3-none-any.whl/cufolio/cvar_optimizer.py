'''
SPDX-FileCopyrightText: Copyright (c) 2021-2025 NVIDIA CORPORATION &
AFFILIATES. All rights reserved. SPDX-License-Identifier:
LicenseRef-NvidiaProprietary

NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
property and proprietary rights in and to this material, related
documentation and any modifications thereto. Any use, reproduction,
disclosure or distribution of this material and related documentation
without an express license agreement from NVIDIA CORPORATION or
its affiliates is strictly prohibited.
'''

from dataclasses import dataclass
import datetime as dt
import os
import json
import copy 

import numpy as np
import pandas as pd
import math
import scipy
from scipy.stats import norm
from scipy.sparse import csr_matrix
import cvxpy as cp

import matplotlib.pyplot as plt
import seaborn as sns

from . import base_optimizer, cvar_utils, utils
from .portfolio import Portfolio

from cuopt import linear_programming as lp
import time

import msgpack # msgpack was used for the old dictionary-based model

FILE_FORMAT = '.json'

@dataclass 
class CVaR_Data: 
    mean: np.ndarray       # (n_assets,) array of mean returns
    covariance: np.ndarray #(n_assets, n_assets) array of covariances
    R: np.ndarray          #(num_scen, n_assets) array of volatilities
    p: np.ndarray          #(num_scen, ) array of scenario probabilities

@dataclass
class CVaR_Parameters:
    w_min: np.ndarray      #(n_assets,) array of lower bounds on asset weights
    w_max: np.ndarray      #(n_assets,) array of upper bounds on asset weights
    c_min: float           #lower bound on cash weight
    c_max: float           #upper bound on cash weight
    T_tar: float           #turnover limit
    L_tar: float           #leverage target
    cvar_limit:float       #upper bound on CVaR
    risk_aversion: float   #risk-averseness coefficient
    confidence: float      #confidence/confidence-level for CVaR
    num_scen: int          #number of scenarios to generate
    fit_type: str          #multivariate-Gaussian or KDE to fit the returns
        
    def update_w_min(self, new_w_min): 
        self.w_min = new_w_min
    
    def update_w_max(self, new_w_max):
        if new_w_max <= 1:
            self.w_max = new_w_max
        else:
            raise ValueError('Invalid upper bound for weights!')
        
    def update_c_min(self, new_c_min): 
        if new_c_min >= 0: 
            self.c_min = new_c_min
        else: 
            raise ValueError('Cash should be non-negative!')
    
    def update_c_max(self, new_c_max): 
        if new_c_max >= 0 and new_c_max <= 1:
            self.c_max = new_c_max
        else:
            raise ValueError('Invalid upper bound for cash!')
            
    def update_z_min(self, new_c_min): 
        self.z_min = new_c_min
    
    def update_z_max(self, new_z_max): 
        self.z_max = new_z_max
        
    def update_T_tar(self, new_T_tar): 
        self.T_tar = new_T_tar
        
    def update_L_tar(self, new_L_tar): 
        self.L_tar = new_L_tar
    
    def update_risk_aversion(self, new_risk_aversion): 
        if new_risk_aversion > 0:
            self.risk_aversion = new_risk_aversion
        else:
            raise ValueError('Invalid risk aversion')
    def update_num_scen(self, new_num_scen):
        if new_num_scen > 0: 
            self.num_scen = new_num_scen
        else: 
            raise ValueError('Invalid risk aversion')
            
    def update_confidence(self, new_confidence): 
        if new_confidence > 0 and new_confidence <= 1:
            self.confidence = new_confidence
        else: 
            raise ValueError('Invalid confidence level (should be between 0 and 1, e.g. 95%, 99%, etc.)')


class CVaR(base_optimizer.BaseOptimizer):
    '''
    The CVaR class has the following functionality: 
    1. Set up the optimization problem based on the input data and parameters
    2. Solve the optimization problem using CPU or GPU solvers
    3. Save the optimization problem as a file that is compliant with cuOpt solver requirements
    4. Generate efficient frontier with different risk aversion levels
    
    - Inputs: 
        - ``input_file_name`` - str
        - ``return_type`` - str: LOG 
        - ``cvar_params`` - dataclass CVaR_Parameters: optimization parameters
        - ``regime`` - dict: name of the regime, tuple of str: start and end date, if not specified, then dafault to the entire time range of the given dateset
        - ``fit_type`` - str: method to fit the return distributionm (gaussian, kde, etc.)
        - ``existing_portfolio`` - numpy ndarray (n_assets, ): existing portfolio weights
    
    - Outputs: 
        - ``weights`` - np.ndarray (n_assets, ): optimized weights
        - ``cash`` - float: optimized cash
    
    **************
    Public Methods
    **************
    - ``solve_optimization_problem`` solves the optimization problem using a selected device (CPU or GPU) and store the results 
    - ``evaluate_portfolio_performance`` evaluates the performance given any portfolio (weights + cash) and returns portfolio returns, variance, and CVaR
    - ``
    - ``generate_efficient_frontier`` generates the efficient frontier for the current dataset and regime
    
    '''
    
    def __init__(self, returns_dict, cvar_params, problem_from_file = None, existing_portfolio = None):
        
        super().__init__(returns_dict, existing_portfolio, 'CVaR')

#       self.cuOpt_data_directory = cuOpt_data_directory #cuOpt data directory specified for docker container
        self.regime_name = returns_dict['regime']['name']   # the regime name
        self.regime_range = returns_dict['regime']['range'] # tuple recording the start and end of regime
        self.data = returns_dict['cvar_data']
        self.existing_portfolio = existing_portfolio
        self.params = copy.deepcopy(cvar_params)
        
        self.problem_from_file = problem_from_file          # solve the problem from file or set up the problem if None
        
        #set up the optimization problem
        self._set_up()
        
        self.optimal_portfolio = None
        self.custom_portfolios = pd.DataFrame([], columns = ['portfolio_name', 'weights', 'cash', 'return', 'variance', 'CVaR'])
        
        #internal variables
        self._cpu_problem = None
        
        #columns of dataframe to store results
        self._result_columns = ['regime', 'solve time', 'return',  'CVaR', 'obj']
        
        
    def _set_up(self):
        '''
        set up the optimization from scratch or from file
        ''' 
        if self.problem_from_file is None:
            set_up_start = time.time()
            self._scale_risk_aversion()
            
            #based on the cvar params, select the corresponding type of optimization model to use
            #1. basic cvar
            #2. cvar with constraint on cvar limit
            #3. cvar with constraints on cvar limit and tracking error
            if self.params.cvar_limit is None and self.params.T_tar is None: 
                problem_flag = 'basic cvar'
            elif isinstance(self.params.cvar_limit, float) and self.params.T_tar is None:
                problem_flag = 'cvar with limit'
            elif isinstance(self.params.cvar_limit, float) and isinstance(self.params.T_tar, float):
                if self.existing_portfolio is not None:
                    problem_flag = 'cvar with limit and turnover'
                else: 
                    print('No existing portfolio: no turnover constraint imposed.')
                    problem_flag = 'cvar with limit'
                    
            elif self.params.cvar_limit is None and isinstance(self.params.T_tar, float): 
                problem_flag = 'cvar with turnover'
            else:
                raise ValueError('check cvar_limit and/or tracking error.')
            
            #set-up the selected problem 
            self._set_up_optimization_problem(problem_flag)
            
            set_up_end = time.time()
            set_up_time = set_up_end - set_up_start
            #print(f'{problem_flag} problem set up! Completed in {set_up_time:.2f} seconds.')
        else: 
            self.read_problem_from_file()
            print(f'Problem read from file!')
            
    def _scale_risk_aversion(self):
        '''
        adjust risk aversion based on the single portfolio mean and cvar so that user input risk aversion remains on the same scale (around 1). 
        '''
        single_portfolio_performance = cvar_utils.evaluate_single_asset_portfolios(self)
        scalar = (single_portfolio_performance['return'] / single_portfolio_performance['CVaR']).max()
        
        self.params.update_risk_aversion(self.params.risk_aversion * scalar)
#       print(f'adjusted risk aversion: {self.params.risk_aversion}')
        
    def _set_up_optimization_problem(self, problem_flag):
        '''
        set up the optimization linear program
        '''
        N = self.n_assets
        M = len(self.data.p)
        
        if problem_flag in ['cvar with limit', 'basic cvar']:
            # Objective vector with penalty on transaction cost
            d = np.concatenate([
                -self.data.mean.T,                   # size N
                [0],                                 # size 1
                [self.params.risk_aversion],         # size 1
                (self.params.risk_aversion / (1 - self.params.confidence)) * self.data.p,  # size M
                np.zeros(N)                          # size N
            ])
        
        # Constructing the constraints (inequality and equality)
        if problem_flag == 'basic cvar':
            G = np.vstack([
                np.hstack([self.data.R.T, np.zeros((M, 1)), np.ones((M, 1)), np.eye(M), np.zeros((M, N))]),  # R (N,M), transpose to fit
                np.hstack([-np.eye(N), np.zeros((N, 1)), np.zeros((N, 1)), np.zeros((N, M)), np.eye(N)]),
                np.hstack([np.eye(N), np.zeros((N, 1)), np.zeros((N, 1)), np.zeros((N, M)), np.eye(N)])
            ])

            # h vector
            h = np.zeros(G.shape[0])

            # Define A matrix and b vector
            A = np.vstack([
                np.hstack([np.ones((1, N)), [[1]], [[0]], np.zeros((1, M)), np.zeros((1, N))]),
                np.hstack([np.zeros((1, N)), [[0]], [[0]], np.zeros((1, M)), np.ones((1, N))])
            ])

            A = np.vstack((A, -G))

            b = np.array([1, self.params.L_tar])
            b = np.hstack([b, -h])
            self._equality_index = 2

            lower_bound_b = ['ninf' for _ in b]
            lower_bound_b[0] = 1 #self-financing
            
            # variables constraints
            lower = np.concatenate([np.full(N, self.params.w_min), [self.params.c_min], [-np.inf], np.full(M, 0), np.zeros(N)])  # Lower bounds
            upper = np.concatenate([np.full(N, self.params.w_max), [self.params.c_max], [np.inf], np.full(M, np.inf), np.full(N, self.params.w_max)])  # Upper bounds
            
        elif problem_flag == 'cvar with limit':
            G = np.vstack([
                np.hstack([self.data.R.T, np.zeros((M, 1)), np.ones((M, 1)), np.eye(M), np.zeros((M, N))]),  # R (N,M), transpose to fit
                np.hstack([-np.eye(N), np.zeros((N, 1)), np.zeros((N, 1)), np.zeros((N, M)), np.eye(N)]),
                np.hstack([np.eye(N), np.zeros((N, 1)), np.zeros((N, 1)), np.zeros((N, M)), np.eye(N)]),
                np.hstack([np.zeros((1,N)), [[0]], [[-1]], [1/(self.params.confidence-1) * self.data.p.T], np.zeros((1,N))])
            ])

            # h vector
            h = np.zeros(G.shape[0])
            h[-1] = -self.params.cvar_limit

            # Define A matrix and b vector
            A = np.vstack([
                np.hstack([np.ones((1, N)), [[1]], [[0]], np.zeros((1, M)), np.zeros((1, N))]),
                np.hstack([np.zeros((1, N)), [[0]], [[0]], np.zeros((1, M)), np.ones((1, N))])
            ])

            A = np.vstack([A, -G])

            b = np.array([1, self.params.L_tar])
            b = np.hstack([b, -h])
            self._equality_index = 2
            
            lower_bound_b = ['ninf' for _ in b]
            lower_bound_b[0] = 1 #self-financing
            
            #variables constraints
            lower = np.concatenate([np.full(N, self.params.w_min), [self.params.c_min], [-np.inf], np.full(M, 0), np.zeros(N)])  # Lower bounds
            upper = np.concatenate([np.full(N, self.params.w_max), [self.params.c_max], [np.inf], np.full(M, np.inf), np.full(N, self.params.w_max)])  # Upper bounds
            
            
        elif problem_flag == 'cvar with turnover': 
             # Objective vector
            d = np.concatenate([
                -self.data.mean.T,                   # size N
                [0],                   # size 1
                [self.params.risk_aversion],         # size 1
                (self.params.risk_aversion / (1 - self.params.confidence)) * self.data.p,  # size M
                np.zeros(N),           # size N            #leverage
                np.zeros(N)            # size N            #turnover
            ])

            w_prev = np.array(self.existing_portfolio.weights)
            
            G = np.vstack([
                np.hstack([self.data.R.T, np.zeros((M, 1)), np.ones((M, 1)), np.eye(M), np.zeros((M, N)), np.zeros((M,N))]),  # R (N,M), transpose to fit
                np.hstack([-np.eye(N), np.zeros((N, 1)), np.zeros((N, 1)), np.zeros((N, M)), np.eye(N), np.zeros((N, N))]),
                np.hstack([np.eye(N), np.zeros((N, 1)), np.zeros((N, 1)), np.zeros((N, M)), np.eye(N), np.zeros((N, N))]),
                np.hstack([np.eye(N), np.zeros((N, 1)), np.zeros((N, 1)), np.zeros((N, M)), np.zeros((N,N)), np.eye(N)]),
                np.hstack([-np.eye(N), np.zeros((N, 1)), np.zeros((N, 1)), np.zeros((N, M)), np.zeros((N,N)), np.eye(N)])
            ])

            # h vector
            h = np.hstack([np.zeros(M), np.zeros(N), np.zeros(N), w_prev, -w_prev])            

            # Define A matrix and b vector
            A = np.vstack([
                np.hstack([np.ones((1, N)), [[1]], [[0]], np.zeros((1, M)), np.zeros((1, N)), np.zeros((1, N))]),
                np.hstack([np.zeros((1, N)), [[0]], [[0]], np.zeros((1, M)), np.ones((1, N)), np.zeros((1, N))]),
                np.hstack([np.zeros((1, N)), [[0]], [[0]], np.zeros((1, M)), np.zeros((1, N)), np.ones((1, N))]),
            ])
            
            A = np.vstack([A, -G])
            
            b = np.array([1, self.params.L_tar, self.params.T_tar])
            b = np.hstack([b, -h])
            self._equality_index = 3
            
            #lower bound required for cuopt
            lower_bound_b = ['ninf' for _ in b]
            lower_bound_b[0] = 1 #self-financing
            
            #variables constraints
            lower = np.concatenate([np.full(N, self.params.w_min), [self.params.c_min], [-np.inf], np.full(M, 0), np.zeros(N), np.zeros(N)])  # Lower bounds
            upper = np.concatenate([np.full(N, self.params.w_max), [self.params.c_max], [np.inf], np.full(M, np.inf), np.full(N, self.params.w_max), np.full(N, self.params.T_tar)])  # Upper bounds
            
        elif problem_flag == 'cvar with limit and turnover':
            # Objective vector
            d = np.concatenate([
                -self.data.mean.T,                   # size N
                [0],                   # size 1
                [self.params.risk_aversion],         # size 1
                (self.params.risk_aversion / (1 - self.params.confidence)) * self.data.p,  # size M
                np.zeros(N),           # size N
                np.zeros(N)            # size N
            ])

            w_prev = np.array(self.existing_portfolio.weights)
            
            G = np.vstack([
                np.hstack([self.data.R.T, np.zeros((M, 1)), np.ones((M, 1)), np.eye(M), np.zeros((M, N)), np.zeros((M,N))]),  # R (N,M), transpose to fit
                np.hstack([-np.eye(N), np.zeros((N, 1)), np.zeros((N, 1)), np.zeros((N, M)), np.eye(N), np.zeros((N, N))]),
                np.hstack([np.eye(N), np.zeros((N, 1)), np.zeros((N, 1)), np.zeros((N, M)), np.eye(N), np.zeros((N, N))]),
                np.hstack([np.zeros((1,N)), [[0]], [[-1]], [1/(self.params.confidence-1) * self.data.p.T], np.zeros((1,N)), np.zeros((1, N))]),
                np.hstack([np.eye(N), np.zeros((N, 1)), np.zeros((N, 1)), np.zeros((N, M)), np.zeros((N,N)), np.eye(N)]),
                np.hstack([-np.eye(N), np.zeros((N, 1)), np.zeros((N, 1)), np.zeros((N, M)), np.zeros((N,N)), np.eye(N)])
            ])

            # h vector
            h = np.hstack([np.zeros(M), np.zeros(N), np.zeros(N), [-self.params.cvar_limit], w_prev, -w_prev])            

            # Define A matrix and b vector
            A = np.vstack([
                np.hstack([np.ones((1, N)), [[1]], [[0]], np.zeros((1, M)), np.zeros((1, N)), np.zeros((1, N))]),
                np.hstack([np.zeros((1, N)), [[0]], [[0]], np.zeros((1, M)), np.ones((1, N)), np.zeros((1, N))]),
                np.hstack([np.zeros((1, N)), [[0]], [[0]], np.zeros((1, M)), np.zeros((1, N)), np.ones((1, N))]),
            ])
            
            A = np.vstack([A, -G])
            
            b = np.array([1, self.params.L_tar, self.params.T_tar])
            b = np.hstack([b, -h])
            self._equality_index = 3
            
            #lower bound required for cuopt
            lower_bound_b = ['ninf' for _ in b]
            lower_bound_b[0] = 1 #self-financing
            
            #variables constraints
            lower = np.concatenate([np.full(N, self.params.w_min), [self.params.c_min], [-np.inf], np.full(M, 0), np.zeros(N), np.zeros(N)])  # Lower bounds
            upper = np.concatenate([np.full(N, self.params.w_max), [self.params.c_max], [np.inf], np.full(M, np.inf), np.full(N, self.params.w_max), np.full(N, self.params.T_tar)])  # Upper bounds
            
        self._variable_size = lower.shape[0]
        self._A = A
        self._b = b
        self._d = d
        self._lower_bound_b = lower_bound_b
        self._lower = lower
        self._upper = upper     
        
    def solve_optimization_problem(self, device = 'CPU', gpu_settings = None, 
                                            cpu_settings = None,
                                            print_result = True, to_file = None): 
        '''
        Set up the linear program and solve
        
        Parameters: 
        :device: str - which device to use for solving the optimization problem
        :gpu_settings: SolverSettings - cuOpt solver settings class (see details in documentation)
        :cpu_verbose: bool - verbose solver or not
        :to_file: tuple - (save_path, ticker_save_path). If none, not save.
        :print_result: bool - display the non-zero weights
        '''
        
        time_dict = {} #dictionary to store 
            
        device = device.upper()
        
        if device == 'CPU': 
            # Define the problem
            print('Solver: ' + cpu_settings['solver'])
            result_row, weights, cash = self._cpu_solve(cpu_settings)
                
        elif device == 'GPU':
            if to_file is not None:
                #time the write file process
                time_dict['write time'] = self._save_problem_for_cuopt(to_file)

            else:
                self._save_problem_for_cuopt()

            #solve the problem on gpu
            IO_start = time.time()
            result_row, weights, cash = self._gpu_solve(gpu_settings)
            IO_end = time.time()
            IO_time = IO_end - IO_start - result_row['solve time']
            time_dict['IO time'] = IO_time
                
        else: 
            raise ValueError('Invalid Device Name!')
        
        # record the portfolio weights and cash
        portfolio = Portfolio(name=device+'_optimal', tickers=self.tickers, weights=weights, cash=cash, time_range = self.regime_range)
        
        # Check whether the solutions satisfy self-financing
        portfolio._check_self_financing()
        
        if print_result: 
            self._print_CVaR_results(result_row, device, portfolio, time_dict)
            
        return result_row, portfolio
    
    def _cpu_solve(self, cpu_settings): 
        '''
        internal method for solving the optimization via CPU solver specified in params
        '''
        N = self.n_assets
        M = len(self.data.p)
        
        x= cp.Variable(self._variable_size)

        # Define optimization objective
        objective = cp.Minimize(self._d.T @ x)
        constraints = [
            self._A[self._equality_index:] @ x <= self._b[self._equality_index:],
            self._A[:self._equality_index] @ x == self._b[:self._equality_index],
            self._lower <= x,
            x <= self._upper
        ]
        
        self._cpu_problem = cp.Problem(objective, constraints)

        # Solve the problem
        result = self._cpu_problem.solve(**cpu_settings)
        returns, cvar, weights, cash = self._process_optimization_results(x.value)

        result_row = pd.Series([self.regime_name, self._cpu_problem.solver_stats.solve_time, 
                                returns, cvar, self._cpu_problem.value], index = self._result_columns)
        
        return result_row, weights, cash
    
    def _gpu_solve(self, settings = None):
        '''
        solve the problem on GPU - cuOpt
        
        Params: 
        ``settings``: solver_settings object - cuOpt settings class
        '''
        if settings is None: 
            settings = lp.SolverSettings()
            
        solution = lp.Solve(self.cuOpt_model, settings)
        
        solver_time = solution.get_solve_time() * 1e-3
        solver_solution = solution.get_primal_solution()
        returns, cvar, weights, cash = self._process_optimization_results(solver_solution)
        
        obj = solution.get_primal_objective()
        result_row = pd.Series([self.regime_name, solver_time, 
                                returns, cvar, obj], index = self._result_columns)
        
        return result_row, weights, cash
    
    def _process_optimization_results(self, solver_solution): 
        '''
        solver_solution is the optimization result returned by solver. Retrieve key information from x. 
        '''
        weights = solver_solution[:self.n_assets]
        cash = solver_solution[self.n_assets]
        t = solver_solution[self.n_assets + 1]
        u = solver_solution[self.n_assets+2: self.n_assets + self.params.num_scen + 2]
        
        returns = self.data.mean @ weights
        cvar = t + (1 / (1-self.params.confidence) * self.data.p) @ u
        
        return returns, cvar, weights, cash
        
    def _print_CVaR_results(self, result_row, device, portfolio, time_dict, cut_off = 1e-3, rounding = 3): 
        '''
        clean the raw weights, setting any weights whose absolute
        values are below the cutoff to zero, and rounding the rest. Then print the results
        params:
        :result_row: the pd series recording the optimization results
        :portfolio: portfolio object
        :time_dict: dictionary storing additional time information
        :cut_off: the cut-off threshold for weights to print
        :rounding: # digits to round
        
        return: 
        :optimal_portfolio: tuple (optimal weights, cash)
        '''
        residual = 0
        # Display the results
        print('*************************')
        print('--- ' + device + ' CVaR Results---')
        print(f'{self.regime_name}: {self.regime_range}')
        print(f'Scenarios: {self.params.num_scen}')
        print("solver time: {:.4f} seconds".format(result_row['solve time']))
        for key, value in time_dict.items():
            print(f'{key}: {value :.4f} seconds')
        print('--- Optimal Portfolio ---' )    
        portfolio.print_clean(verbose = True)
        print('*************************\n')

    def _value_to_sdk_inf(self, value):
        """Converts various infinity representations to np.PINF/NINF."""
        if isinstance(value, str):
            if value.lower() == "inf": return np.PINF
            if value.lower() == "ninf": return np.NINF
        if value == float('inf'): return np.PINF
        if value == float('-inf'): return np.NINF
        if np.isposinf(value): return np.PINF
        if np.isneginf(value): return np.NINF
        return float(value)
        
    def _sdk_list_to_float_array(self, data_list):
        """Converts a list (potentially with inf strings/objects) to a numpy float array with np.PINF/NINF."""
        return np.array([self._value_to_sdk_inf(v) for v in data_list], dtype=np.float64)
        
    def _save_problem_for_cuopt(self, to_file = None, file_format = None):
        """Populate a cuOpt DataModel from the in‑memory NumPy/SciPy state."""
        dm = lp.DataModel()

        # Constraint matrix -------------------------------------------------
        csr_A = csr_matrix(self._A)
        dm.set_csr_constraint_matrix(
            csr_A.data.astype(np.float64),
            csr_A.indices.astype(np.int32),
            csr_A.indptr.astype(np.int32),
        )

        # Bounds ------------------------------------------------------------
        b = [cvar_utils.convert_to_compliant(value) for value in self._b]
        np_constraint_ub = self._sdk_list_to_float_array(b)
        np_constraint_lb = self._sdk_list_to_float_array(self._lower_bound_b)
        dm.set_constraint_bounds(np_constraint_ub)
        dm.set_constraint_lower_bounds(np_constraint_lb)
        dm.set_constraint_upper_bounds(np_constraint_ub)

        # Objective ---------------------------------------------------------
        dm.set_objective_coefficients(np.asarray(self._d.tolist(), dtype=np.float64))
        dm.set_objective_scaling_factor(1.0)
        dm.set_objective_offset(0.0)

        # Variable bounds ---------------------------------------------------
        upper = [cvar_utils.convert_to_compliant(value) for value in self._upper]
        lower = [cvar_utils.convert_to_compliant(value) for value in self._lower]
        dm.set_variable_lower_bounds(self._sdk_list_to_float_array(lower))
        dm.set_variable_upper_bounds(self._sdk_list_to_float_array(upper))

        # Problem is a minimization -----------------------------------------
        dm.set_maximize(False)

        self.cuOpt_model = dm # Store the DataModel instance

        """
        self.cuOpt_model = {
            'csr_constraint_matrix': {
                'offsets': csr_A.indptr.tolist(),
                'indices': csr_A.indices.tolist(),
                'values': csr_A.data.tolist()
            },
            'constraint_bounds': {
                'bounds': b,
                'upper_bounds': b,  # From problem constraints
                'lower_bounds': self._lower_bound_b    # Assuming no specific lower bounds are provided
            },
            'objective_data': {
                'coefficients': self._d.tolist(),  # Extract coefficients
                'scalability_factor': 1.0,
                'offset': 0.0
            },
            'variable_bounds': {
                'upper_bounds': upper,  
                'lower_bounds': lower  
            },
            'maximize': False,  # Problem is a minimization
            'solver_config': {}
        }
        """
        
        #save the problem file if necessary
        if to_file is not None:
            write_start = time.time()
            save_path = utils.create_save_path(to_file[0], to_file[1] + FILE_FORMAT)
            ticker_save_path = utils.create_save_path(to_file[0], 'tickers.json')
            
            problem_dict_to_save = lp_parser.toDict(dm, json=True)
            # Use cuOpt parser to parse data_model before saving
            model_json = json.dumps(problem_dict_to_save, indent=4)
            model_data = json.loads(model_json)
            with open(save_path, 'wb') as out:
                msgpack.dump(problem_dict_to_save, out)

            if not os.path.exists(ticker_save_path):
                ticker_json = json.dumps(list(self.tickers), indent = 4)
                with open(ticker_save_path, 'w') as file:
                    file.write(ticker_json)
            write_end = time.time()
            
            write_time = write_end - write_start 
            
            return write_time
        
    def read_problem_from_file(self):
        '''
        read the problem from a given directory
        '''
        with open(self.problem_from_file + FILE_FORMAT, 'rb') as f:
            opt_problem = msgpack.load(f)

        # Extract csr_constraint_matrix data and reconstruct the csr_matrix
        offsets = np.array(opt_problem['csr_constraint_matrix']['offsets'])
        indices = np.array(opt_problem['csr_constraint_matrix']['indices'])
        values = np.array(opt_problem['csr_constraint_matrix']['values'])

        # Reconstruct the csr_matrix
        self._A = csr_matrix((values, indices, offsets))

        # Access the constraint bounds
        self._b = opt_problem['constraint_bounds']['bounds']
        self._lower_bound_b = opt_problem['constraint_bounds']['lower_bounds']

        # Access the objective data
        self._d = np.array(opt_problem['objective_data']['coefficients'])

        # Access variable bounds
        upper = opt_problem['variable_bounds']['upper_bounds']
        lower = opt_problem['variable_bounds']['lower_bounds']
        
        self._upper = [cvar_utils.convert_from_file(value) for value in upper]
        self._lower = [cvar_utils.convert_from_file(value) for value in lower]
