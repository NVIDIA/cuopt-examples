'''
SPDX-FileCopyrightText: Copyright (c) 2021-2025 NVIDIA CORPORATION &
AFFILIATES. All rights reserved. SPDX-License-Identifier:
LicenseRef-NvidiaProprietary

NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
property and proprietary rights in and to this material, related
documentation and any modifications thereto. Any use, reproduction,
disclosure or distribution of this material and related documentation
without an express license agreement from NVIDIA CORPORATION or
its affiliates is strictly prohibited.
'''

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import json

class Portfolio:
    """
    Data:
    - ``name`` - str
    - ``tickers`` - str list
    - ``weights`` - numpy array (n_assets,)
    - ``cash`` - float

    Public methods:

    - ``set_weights`` sets weights (np.ndarray) from a weights dict
    - ``get_weights`` returns weights (np.ndarray) 
    - ``clean_weights`` rounds the weights and clips near-zeros.
    - ``set_cash`` sets the amount of cash
    - ``get_cash`` gets the amount of cash
    """
    
    def __init__(self, name='', tickers=[], weights=[], cash=0.0, time_range = None):
        self.name = name # portfolio name or ''
        self.tickers = tickers
        self._n_assets = len(self.tickers)
        self.weights = weights 
        self.cash = float(cash)
        self.time_range = time_range
    
    def __eq__(self, other_portfolio, atol = 1e-3):
        if isinstance(other_portfolio, Portfolio):
            return np.allclose(self.weights, other_portfolio.weights, atol = atol)
        return False
    
    def _check_self_financing(self, weights = [], cash = None):
        '''
        given portfolio weights and cash, check if the self-financing condition is satisfied.
        '''
        ### Throws error comparing weights directly to an empty list triggers elementwise comparison
        #if weights == []: 
            #weights = self.weights

        if len(weights) == 0:
            weights = self.weights
            
        if cash is None: 
            cash = self.cash
        
        self_finance = np.sum(weights) + cash

        if np.abs(self_finance - 1) > 1e-3:
            print(f'weights: {np.sum(weights)}; cash: {cash}')
            raise ValueError("Portfolio weights and cash do not sum to 1!")
        
    def portfolio_from_dict(self, portfolio_name, user_portfolio_dict, cash):
        '''
        generate portfolio from user input (dictionary)
        
        Params: 
        :portfolio_name: str - name of the portfolio
        :user_portfolio_dict: dict - {ticker: weight}
        :cash: float        
        '''
        
        weights = pd.Series(dtype = np.float64, index = self.tickers)
        
        for ticker, weight in user_portfolio_dict.items():
            ticker = ticker.upper()
            if ticker in self.tickers:
                weights[ticker] = weight
            else: 
                raise ValueError('Selected ticker is not available in the dataset!')

        weights = weights.fillna(0).T
        weights = weights.to_numpy()
        
        self._check_self_financing(weights, cash)
        
        self.weights = np.array(weights)
        self.cash = float(cash)
        self.name = portfolio_name
    
    def print_clean(self, cutoff = 1e-3, rounding = 3, verbose=False):
        
        residual = 0
        clean_ptf_dict = {}
        for idx, ticker in enumerate(self.tickers):
            value = self.weights[idx]
            if value > cutoff:
                clean_ptf_dict[ticker] = value
                if verbose:
                    print(f'Long--{ticker}: {value.round(rounding)}')
                
            elif value < -cutoff:
                clean_ptf_dict[ticker] = value
                if verbose:
                    print(f'Short--{ticker}: {value.round(rounding)}')
            else: 
                residual += value
        
        cash = round(self.cash, rounding)
        
        if verbose:
            print(f'cash: {cash}')
        
        return (clean_ptf_dict, float(cash))
    
    def calculate_portfolio_expected_return(self, mean):
        '''
        take the given portfolio weights and calculate expected return
        params: 
        :mean: numpy array (self._n_assets, ) - mean returns
        '''
        assert (mean.shape[0] == self._n_assets), f'Incorrect mean vector size! Expecting: {self._n_assets}.'
        
        return mean @ self.weights
    
    def calculate_portfolio_variance(self, covariance):
        '''
        take the given portfolio weights and calculate expected return
        params: 
        :covariance: numpy ndarray (self._n_assets, self._n_assets) - covariance of returns (of return type)
        '''
        assert (covariance.shape[0] == self._n_assets or covariance.shape[1] != self._n_assets),\
                f'Incorrect covariance size! Expecting: {self._n_assets} by {self._n_assets}.'
        
        return self.weights.T @ covariance @ self.weights

    def plot_portfolio(self, show_plot = False, ax = None, title = None):        
        if ax is None:
            fig, ax = plt.subplots(figsize=(10, 6))
            
        if self._n_assets <= 30: 
            tickers = self.tickers
            weights = self.weights
            cash = self.cash
        else: 
            portfolio = self.print_clean()
            tickers = list(portfolio[0].keys())
            weights = list(portfolio[0].values())
            cash = portfolio[1]
            
        colors = ['#76b900' if value >= 0 else 'r' for value in weights]
        ax.barh(tickers, weights, color = colors)
        ax.barh('cash', cash, color = '#76b900')
        
        ax.set_ylabel('Tickers', fontsize = 8)
        ax.set_xlabel('Portfolio Weights', fontsize = 8)
        if self.time_range is not None:
            start = self.time_range[0]
            end = self.time_range[1]
            if title is None:
                title = f'Portfolio from {start} to {end}'

            ax.set_title(title, fontsize = 10)
            
        ax.set_xlim(-1, 1)
        ax.axvline(0, color = "k")
        ax.tick_params(axis='both', labelsize=8)
        
        if show_plot:
            plt.show()
        
        return ax
    
    def save_portfolio(self, save_path):
        '''
        save the portfolio class as a json file at a given path
        '''
        save_weights = self.weights.tolist()
        
        portfolio = {'name': self.name, 'weights': save_weights, 'cash': self.cash, 'tickers': self.tickers, 'time_range': self.time_range}
        
        with open(save_path, 'w') as json_file:
            json.dump(portfolio, json_file, indent=4)
            
    def load_portfolio_from_json(self, load_path): 
        '''
        load a portfolio from a json file from a given path
        '''
    
        with open(load_path, 'r') as json_file:
            data = json.load(json_file)
            
        self.name = data['name']
        self.tickers = data['tickers']
        self._n_assets = len(self.tickers)
        weights = np.array(data['weights'])
        self._check_self_financing(weights, data['cash'])
        self.weights = weights
        self.cash = data['cash']
        
        
        self.time_range = data['time_range']
